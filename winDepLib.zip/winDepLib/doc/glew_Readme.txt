This directory contain pre-build binary
of freeglut and glew for Windows.
Which is the OpenGL wrapper for IcEng.

Read License and Readme inside doc.

To get more info about freeglut and glew,
visit web page :
http://freeglut.sourceforge.net/
http://glew.sourceforge.net/

